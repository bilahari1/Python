from Graphics import Circle
from Graphics import Rectangle
from Graphics.dgraphics import Cuboid
from Graphics.dgraphics import Sphere

rc = int(input("Enter radius of the circle "))
Circle.areac(rc)
Circle.peric(rc)

l = int(input("Enter length and breadth of rectangle\n"))
b = int(input())
Rectangle.arear(l,b)
Rectangle.perir(l,b)

l1 = int(input("Enter the length breadth and height of cuboid\n"))
b1 = int(input())
h1 = int(input())
Cuboid.areacu(l1,b1,h1)
Cuboid.pericu(l1,b1,h1)

r1 = int(input("Enter the radius of sphere :"))
Sphere.areas(r1)
Sphere.peris(r1)
