def areac(r):
    a = 3.14 * r * r
    print("Area of circle : ", a)


def peric(r):
    p = 2 * 3.14 * r
    print("Perimeter of circle : ", p)

