def areacu(l, b, h):
    a = 2 * ((l * b) + (b * h) + (h * l))
    print("Area of cuboid : ", a)


def pericu(l, b, h):
    p = 4 * (l + b + h)
    print("Perimeter of cuboid : ", p)
