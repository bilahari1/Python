def arear(l,b):
    a = l * b
    print("Area of rectangle : ",a)

def perir(l,b):
    p = 2 * (l + b)
    print("Perimeter of rectagle : ",p)


